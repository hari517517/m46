﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_CRUD.Models;

namespace MVC_CRUD.Controllers
{
    public class StudentController : Controller
    {

       public static List<Student_Master> stdlist = new List<Student_Master>();
        // GET: Insert

        public ActionResult Retrieve()
        {
            return View(stdlist);
        }



        [HttpGet]
        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert(Student_Master student)
        {
           
            stdlist.Add(student);
            return RedirectToAction("Retrieve");
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            Student_Master std =( from s in stdlist
                      where s.Stud_Code == id
                      select s).Single();
            return View(std);
        }
        [HttpPost]
        public ActionResult Update(Student_Master std)
        {
            Student_Master std1 = (from s in stdlist
                                  where s.Stud_Code ==std.Stud_Code
                                  select s).Single();
            std1.Stud_Name = std.Stud_Name;
            std1.Dept_Code = std.Dept_Code;
            std1.Doj = std.Doj;
            std1.Address = std.Address;
            return RedirectToAction("Retrieve");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            Student_Master std1 = (from s in stdlist
                                   where s.Stud_Code == id
                                   select s).Single();
            stdlist.Remove(std1);
            return RedirectToAction("Retrieve");
        }

        public ActionResult Details(int id)
        {
            Student_Master std1 = (from s in stdlist
                                   where s.Stud_Code == id
                                   select s).Single();
            return PartialView("_Details",std1);
            
        }
        
    }
}