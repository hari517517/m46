﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MVC_CRUD.Models
{
    public class Student_Master
    {
        [Required]
        public int Stud_Code { get; set; }
        [Required]
        public string Stud_Name { get; set; }
        [Required]
        public int Dept_Code { get; set; }
        [Required]
        public DateTime Doj { get; set; }
        [Required]
        public string Address { get; set; }
    }
}